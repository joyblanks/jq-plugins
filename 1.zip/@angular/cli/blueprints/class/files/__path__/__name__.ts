export class <%= classifiedModuleName %> {
}
