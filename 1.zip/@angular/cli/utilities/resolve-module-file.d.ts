export declare function resolveModulePath(moduleNameFromFlag: string, project: any, projectRoot: any, appConfig: any): string;
