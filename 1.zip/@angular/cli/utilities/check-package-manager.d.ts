export declare function checkYarnOrCNPM(): any;
