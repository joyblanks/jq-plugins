export default function findParentModule(projectRoot: string, appRoot: string, currentDir: string): string;
