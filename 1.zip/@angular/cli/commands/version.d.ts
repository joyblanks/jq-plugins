declare const VersionCommand: any;
export default VersionCommand;
