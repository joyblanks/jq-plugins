declare const DocCommand: any;
export default DocCommand;
