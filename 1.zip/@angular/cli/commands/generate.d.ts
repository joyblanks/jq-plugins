declare const GenerateCommand: any;
export default GenerateCommand;
