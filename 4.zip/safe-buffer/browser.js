module.exports = require('buffer')
