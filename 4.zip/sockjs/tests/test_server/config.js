exports.config = {
    server_opts: {
        sockjs_url: 'http://localhost:8080/lib/sockjs.js',
        websocket: true
    },

    port: 8081,
    host: '0.0.0.0'
};
