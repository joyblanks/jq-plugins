declare function noCase (value: string, locale?: string, replacement?: string): string;

export = noCase;
