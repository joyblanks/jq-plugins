# node-modules-path [![Build Status](https://travis-ci.org/ember-cli/node-modules-path.svg)](https://travis-ci.org/ember-cli/node-modules-path)
