- Instructions to install and configure any prerequisites or dependencies
- Instructions to create and initialize the database
- Instructions to configure and prepare the source code to build and run properly
- Assumptions you have made - it is good to explain your thought process and the assumptions you have made
- Any issues you have faced while completing the assignment
- Any constructive feedback for improving the assignment


Prepare Environment

1. Import Code in IDE (**Eclipse v.Neon.1 was used to build + Windows7 64bit) File->Import->Existing Maven Projects-> codebase ~ pom.xml
2. Add Plugin M2E for Maven
3. Download Maven and Tomcat and point in preferences of Eclipse
4. Download and Install MySQL
5. Setup JAVA_HOME to a JDK in Environment variables
6. Setup Path variable for MAVEN, MYSQL, TOMCAT in Environment System Variables
7. Setup Upload folder to C:\Users\<Your_User>\upload and copy files and folders from this .ZIP/PDFs/** to ~/upload
8. In Eclipse Run Maven Install via pom.xml to load dependencies
9. Run Database scripts from .zip/SQL/*
10. In Application.Properties change based on your environment like the below ones or others 
	spring.datasource.url=jdbc:mysql://localhost:3306/journals?createDatabaseIfNotExist=true
	spring.datasource.username=root
	spring.datasource.password=root
	spring.mail.host=smtp.live.com
	spring.mail.port=587
	spring.mail.username=joy.blanks@hotmail.com
	spring.mail.password=XXXXXXX
	send.from.email=info@journals.crossover.com
11. Coverage Report: Optional: Download Eclipse plugin Eclemma and Run Coverage report
12. Software Details
	OS: Win7 64
	IDE: Eclipse v Neon.1
	Maven: Apache Maven 3.3.9 
	Java: JDK: v 1.8.0_111, vendor: Oracle Corporation
	MySQL: v 5.5.49
	Tomcat: v 6.0.48
13. Run the application

Run instructions

	1. Configure the database connection data from Code/src/main/resources/application.properties
	2. Go to the Code folder and run "mvn spring-boot:run".
	3. Go to http://localhost:8080
	4. (Optional) By default, the application stores the uploaded PDFs in <User_home>/upload directory. If you want to change this directory, you can use the -Dupload-dir=<path> system property.
	5. (Optional) The PDFs for the predefined journals can be found in the PDFs folder. If you want to view the predefined journals, you should copy the contents of this folder to the upload folder defined in step 4.
	
	
Authentication data

	The system comes with 4 predefined user accounts. They are:
		1. publishers:
			- username: publisher1 / password: publisher1
			- username: publisher2 / password: publisher2
		2. public users:
			- username: user1 / password: user1
			- username: user2 / password: user2


Assumptions:
1. All User will have email Ids
2. Daily Email will be sent on the first hour of a new day ie in between 00:00:00 hours 00:59:59 and will collect all journals from yesterday4
3. The scheduler will run hourly and fire email only if the time range lies inbetween #2
4. Junit for EmailService should be tested with a FakeSmtp server to hadle response locally via headers
5. Database ddl-create mode only not update to run junits
6. Categories will be added never deleted/edited


Feedback
Better instructions is required to setup the project. 
Angular is a powerful framework as well should have environment of Node + Gulp + Karma + Jasmine and requires modularization of the static code base + Unit and Integration tests
Should have Integration Test Selenium and Protractor 
Should Upgrade to Gradle as the configuration is readable and lighter
UML tool support should be added.

