package com.crossover.trial.journals.model;

public enum Role {
	USER, PUBLISHER
}