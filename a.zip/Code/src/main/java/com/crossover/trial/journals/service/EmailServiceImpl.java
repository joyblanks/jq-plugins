package com.crossover.trial.journals.service;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.MailException;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;

import com.crossover.trial.journals.model.Category;
import com.crossover.trial.journals.model.Journal;
import com.crossover.trial.journals.model.User;
import com.crossover.trial.journals.repository.CategoryRepository;
import com.crossover.trial.journals.util.Utility;

@Service
public class EmailServiceImpl implements EmailService {
	private final static Logger log = Logger.getLogger(EmailServiceImpl.class);
	
	@Autowired
	private CategoryRepository categoryRepository;
	
	@Autowired
	private JavaMailSender mailSender;
	
	private SimpleMailMessage message;
	
	@Value("${send.from.email}")
	private String from;
	
	@Value("${email.subject.publish}")
	private String subjectPublish;
	
	@Value("${email.subject.digest}")
	private String subjectDigest;
	
	/**
	 * EmailServiceImpl::sendMailToCategorySubscribers()
	 * Sends a mail when a journal is published to the Users subscribed to the Category where the Journal was published
	 * 
	 * @param journal
	 * @param categoryId
	 * @param users
	 */
	@Override
	public void sendMailToCategorySubscribers(Journal journal, Long categoryId, List<User> users){
		List<String> emails = new ArrayList<String>(users.size());
		users.stream().forEach(u -> emails.add(u.getEmail()));
		Category category = categoryRepository.findOne(categoryId);
		if(!emails.isEmpty()){
			this.message = new SimpleMailMessage();
			this.message.setSubject(String.format(subjectPublish, journal.getName(), category.getName()));
			this.message.setFrom(from);
			this.message.setBcc(emails.toArray(new String[0]));
			this.message.setText(String.format(subjectPublish, journal.getName(), category.getName()));
			
			try{
				this.mailSender.send(new SimpleMailMessage(this.message));
				log.info("Sent Email" + String.format(subjectPublish, journal.getName(), category.getName()));
			}catch(MailException e){
				log.error(e);
				throw new ServiceException("Failed to send an email");
			}
		}
		
	}
	
	/**
	 * EmailServiceImpl::sendDailyDigest()
	 * Sends an email digest of the journals that were published today.
	 * 
	 * @param journals
	 * @param categoryId
	 */
	@Override
	public void sendDailyDigest(List<Journal> journals, List<User> users) {
		List<String> emails = new ArrayList<String>(users.size());
		users.stream().forEach(u -> emails.add(u.getEmail()));
		Date today = new Date();
		SimpleDateFormat dateFormat = new SimpleDateFormat("dd/MMM/yyyy");
		StringBuffer body = new StringBuffer();
		body.append("Journal\t\t\tCategory\t\t\tPublisher\n");
		if(!emails.isEmpty() && !journals.isEmpty()){
			this.message = new SimpleMailMessage();
			this.message.setSubject(String.format(subjectDigest, dateFormat.format(today)));
			this.message.setFrom(from);
			this.message.setBcc(emails.toArray(new String[0]));
			
			journals.stream().forEach(journal -> body.append(Utility.makeJournalEntry(journal)));
			this.message.setText(body.toString());
			try{
				this.mailSender.send(new SimpleMailMessage(this.message));
				log.info("Sent Email" + String.format(subjectDigest, dateFormat.format(today)));
			}catch(MailException e){
				log.error(e);
				throw new ServiceException("Failed to send  daily digest");
			}
		}
	}
}
