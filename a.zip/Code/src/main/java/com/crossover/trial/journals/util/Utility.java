/**
 * 
 */
package com.crossover.trial.journals.util;

import java.util.Calendar;
import java.util.Date;

import com.crossover.trial.journals.model.Journal;

/**
 * @author Joy
 *
 */
public class Utility {
	
	public static String makeJournalEntry(Journal journal){
		return journal.getName() + "\t\t\t" + journal.getCategory().getName() + "\t\t\t" + journal.getPublisher().getName() + " \n ";
		
	}
	
	public static Date getStartDate(){
		Calendar c = Calendar.getInstance();
		if(c.get(Calendar.HOUR)==0){
			c.add(Calendar.DATE, -1);
		}
		c.set(Calendar.HOUR,0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		//c.add(Calendar.DATE, -2);//for testing
		return c.getTime();
	}
	
	public static Date getEndDate(){
		Calendar c = Calendar.getInstance();
		c.set(Calendar.HOUR,0);
		c.set(Calendar.MINUTE, 0);
		c.set(Calendar.SECOND, 0);
		
		c.add(Calendar.SECOND, -1);
		//c.add(Calendar.DATE, 2);//For Testing
		return c.getTime();
	}
	
	public static boolean isNewDay(){
		Calendar c = Calendar.getInstance();
		return (c.get(Calendar.HOUR)==0);
	}
}
