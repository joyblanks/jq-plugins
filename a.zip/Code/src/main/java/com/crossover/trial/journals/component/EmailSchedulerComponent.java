package com.crossover.trial.journals.component;

import java.util.Date;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import com.crossover.trial.journals.service.EmailService;
import com.crossover.trial.journals.service.JournalService;
import com.crossover.trial.journals.service.UserService;
import com.crossover.trial.journals.util.Utility;


@Component
public class EmailSchedulerComponent {

    private static final Logger log = Logger.getLogger(EmailSchedulerComponent.class);
    
    @Autowired
    private JournalService journalService;
    
    @Autowired
    private EmailService emailService;

    @Autowired
    private UserService userService;
    
    /**
     * EmailSchedulerComponent::taskHourly()
     *  - A scheduled task that runs hourly to find out 
     * 		if it is a new day the first hour of every day and 
     * 		if yes then sends out all journals that were published the previous day
     */
    //@Scheduled(fixedRate = 10000)
    @Scheduled(fixedRate = 3600000) //Run Hourly
    public void taskHourly() {
        if(Utility.isNewDay()){//Fire Next Day at 12:xx:xx AM
        	emailService.sendDailyDigest(journalService.listTodaysJournals(Utility.getStartDate(), Utility.getEndDate()), userService.allUsers());
        }else{
        	log.info("Daily Digest was not sent : Task Run at" + new Date());
        }
        
    }
}