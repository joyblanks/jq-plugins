/**
 * 
 */
package com.crossover.trial.journals.service;

import java.util.List;

import com.crossover.trial.journals.model.Journal;
import com.crossover.trial.journals.model.User;

/**
 * @author Joy
 *
 */
public interface EmailService {
	public void sendMailToCategorySubscribers(Journal journal, Long categoryId, List<User> users);
	
	public void sendDailyDigest(List<Journal> journals, List<User> users);
}
