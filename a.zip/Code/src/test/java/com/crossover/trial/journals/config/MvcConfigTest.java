/**
 * 
 */
package com.crossover.trial.journals.config;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.view;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.MockitoAnnotations;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.crossover.trial.journals.Application;

@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
public class MvcConfigTest {

	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webApplicationContext;

	@Before
	public void setup() throws Exception {
		MockitoAnnotations.initMocks(this);
		this.mockMvc = webAppContextSetup(webApplicationContext).dispatchOptions(true).build();
	}

	
	@Test
	public void addViewControllers() throws Exception {
		mockMvc.perform(get("/"))
	        .andExpect(status().isOk())
	        .andExpect(view().name("home"));
		mockMvc.perform(get("/journals"))
	        .andExpect(status().isOk())
	        .andExpect(view().name("journals"));
		mockMvc.perform(get("/login"))
	        .andExpect(status().isOk())
	        .andExpect(view().name("login"));
		mockMvc.perform(get("/publisher/browse"))
	        .andExpect(status().isOk())
	        .andExpect(view().name("publisher/browse"));
		mockMvc.perform(get("/403"))
	        .andExpect(status().isOk())
	        .andExpect(view().name("403"));
		
		//-ve
		mockMvc.perform(get("/notThere"))
	        .andExpect(status().is4xxClientError());
	
	}
}

