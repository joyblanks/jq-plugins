/**
 * 
 */
package com.crossover.trial.journals.service;

import static org.hamcrest.CoreMatchers.not;
import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertThat;
import static org.junit.Assert.fail;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.Test;
import org.junit.runner.RunWith;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.transaction.annotation.Transactional;

import com.crossover.trial.journals.Application;
import com.crossover.trial.journals.model.Subscription;
import com.crossover.trial.journals.model.User;
import com.crossover.trial.journals.repository.SubscriptionRepository;
import com.crossover.trial.journals.repository.UserRepository;

/**
 * @author Joy
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
public class UserServiceImplTest {
	
	
	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private SubscriptionRepository subscriptionRepository;
	
	
	@Test
	public void allUsers() {
		assertEquals(userRepository.findAll().size(), userService.allUsers().size());
	}
	@Test
	public void getSubscribedUsers(){
		List<User> subUsers = new ArrayList<User>();
		List<User> subUsersFromService = userService.getSubscribedUsers(3l);
		List<Subscription> allSubscriptions = subscriptionRepository.findAll();
		
		allSubscriptions.stream().filter(s->s.getCategory().getId()==3l)
		.forEach(s -> subUsers.add(s.getUser()));
		
		assertEquals(1, subUsersFromService.size(), subUsers.size());
		
		assertEquals("user1", subUsersFromService.get(0).getLoginName(), subUsers.get(0).getLoginName());
	
	}
	
	
	@Test
	public void findById(){
		User user = userService.findById(3l);
		
		assertEquals("user1", user.getLoginName());
	}
	
	@Test
	@Transactional
	public void subscribe(){
		User user = getUser("user1");//3l UserId
		int before = user.getSubscriptions().size();
		userService.subscribe(user, 4l);
		
		User userById = userService.findById(3l);
		int after = userById.getSubscriptions().size();
		
		assertThat(before, not(after));
		assertEquals(before+1, after);
	}
	
	@Test(expected = ServiceException.class)
	public void subscribeFail(){
		User user = getUser("user1");//3l UserId
		int before = user.getSubscriptions().size();
		userService.subscribe(user, 9l);
		
		User userById = userService.findById(3l);
		int after = userById.getSubscriptions().size();
		
		assertThat(before, not(after));
		assertEquals(before+1, after);
	}
	
	
	protected User getUser(String name) {
		Optional<User> user = userService.getUserByLoginName(name);
		if (!user.isPresent()) {
			fail("user1 doesn't exist");
		}
		return user.get();
	}

}
