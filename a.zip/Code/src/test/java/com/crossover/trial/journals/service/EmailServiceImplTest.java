/**
 * 
 */
package com.crossover.trial.journals.service;

import static org.junit.Assert.fail;
import static org.springframework.test.web.servlet.setup.MockMvcBuilders.webAppContextSetup;

import java.util.List;
import java.util.Optional;

import org.junit.Before;
import org.junit.Test;
import org.junit.runner.RunWith;
import org.mockito.Matchers;
import org.mockito.Mockito;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.SpringApplicationConfiguration;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.security.test.web.servlet.setup.SecurityMockMvcConfigurers;
import org.springframework.test.context.junit4.SpringJUnit4ClassRunner;
import org.springframework.test.context.web.WebAppConfiguration;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.web.context.WebApplicationContext;

import com.crossover.trial.journals.Application;
import com.crossover.trial.journals.model.Journal;
import com.crossover.trial.journals.model.User;
import com.crossover.trial.journals.repository.JournalRepository;

/**
 * @author Joy
 *
 */
@RunWith(SpringJUnit4ClassRunner.class)
@SpringApplicationConfiguration(classes = Application.class)
@WebAppConfiguration
public class EmailServiceImplTest {
	
	@Autowired
	private EmailService emailService;
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private JournalService journalService;
	
	@Autowired
	private JournalRepository journalRepository;
	
	//@Mock
	//private JavaMailSender mailSender = Mockito.mock(JavaMailSender.class);
	
	private MockMvc mockMvc;

	@Autowired
	private WebApplicationContext webApplicationContext;
	
	@Before
	public void setup() throws Exception {
		this.mockMvc = webAppContextSetup(webApplicationContext)
				.apply(SecurityMockMvcConfigurers.springSecurity())
				.build();
	}
	
	@Test
	public void sendMailToCategorySubscribers() {
		JavaMailSender spy = Mockito.spy(JavaMailSender.class);
		Mockito.doNothing().when(spy).send(Matchers.any(SimpleMailMessage.class));
		
		List<User> users = userService.allUsers();
		Journal journal = journalRepository.findOne(1l);
		try{
			emailService.sendMailToCategorySubscribers(journal, 3l, users);
		}catch(Exception e){
			//Check Application.properties
		}
	}
	
	@Test
	//@Test(expected = Exception.class)
	public void sendDailyDigest() {
		JavaMailSender spy = Mockito.spy(JavaMailSender.class);
		Mockito.doNothing().when(spy).send(Matchers.any(SimpleMailMessage.class));
		
		List<User> users = userService.allUsers();
		List<Journal> journals = journalService.listAll(getUser("user1"));
		try{
			emailService.sendDailyDigest(journals, users);
		}catch(Exception e){
			//Check Application.properties
		}
	}
	
	protected User getUser(String name) {
		Optional<User> user = userService.getUserByLoginName(name);
		if (!user.isPresent()) {
			fail("user1 doesn't exist");
		}
		return user.get();
	}

}
