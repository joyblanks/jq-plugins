1. Check the version of package you are using. If it's not the newest version, update and try again (see changelog while updating!).
2. If the issue is still there, write a minimal project showing the problem and expected output.
3. Link to the project and mention Node version and OS in your report.

**IMPORTANT! You should use [Stack Overflow](https://stackoverflow.com/) for support related questions.**
