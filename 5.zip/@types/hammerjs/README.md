# Installation
> `npm install --save @types/hammerjs`

# Summary
This package contains type definitions for Hammer.js (http://hammerjs.github.io/).

# Details
Files were exported from https://www.github.com/DefinitelyTyped/DefinitelyTyped/tree/master/hammerjs

Additional Details
 * Last updated: Sat, 24 Dec 2016 20:38:39 GMT
 * Library Dependencies: none
 * Module Dependencies: none
 * Global values: Hammer, HammerInput, MouseInput, PointerEventInput, SingleTouchInput, TouchAction, TouchInput, TouchMouseInput

# Credits
These definitions were written by Philip Bulley <https://github.com/milkisevil/>, Han Lin Yap <https://github.com/codler>.
